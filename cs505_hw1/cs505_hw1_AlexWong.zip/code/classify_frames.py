'''

TODO:
 - Build own classifier
 - Confirm precision and recall methods are correct

'''

from pathlib import Path
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import ComplementNB
from sklearn.linear_model import LogisticRegression

import our_metrics

# Added lib
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
import numpy as np


TRAIN_FILE = Path("raw_data/GunViolence/train.tsv")
DEV_FILE = Path("raw_data/GunViolence/dev.tsv")
TEST_FILE = Path("raw_data/GunViolence/test.tsv")

LABELS = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# These frames/labels correspond to
# 1) Gun or 2nd Amendment rights
# 2) Gun control/regulation
# 3) Politics
# 4) Mental health
# 5) School or public space safety
# 6) Race/ethnicity
# 7) Public opinion
# 8) Society/culture
# 9) Economic consequences


def load_data_file(data_file, is_test_file = False):
    """Load newsframing data

    Returns
    -------
    tuple
        First element is a list of strings(headlines)
        If `data_file` has labels, the second element
        will be a list of labels for each headline. 
        Otherwise, the second element will be None.
    """
    print("Loading from {} ...".format(data_file.name), end="")
    text_col = "news_title"
    theme1_col = "Q3 Theme1"

    with open(data_file) as f:
        df = pd.read_csv(f, sep="\t")
        X = df[text_col].tolist()

        y = None
        if not is_test_file:
            if theme1_col in df.columns:
                y = df[theme1_col].tolist()

        print(
            "loaded {} lines {} labels ... done".format(
                len(X), "with" if y is not None else "without"
            )
        )

    return (X, y)

def build_naive_bayes():
    """

    Returns
    -------
        Pipeline
        An sklearn Pipeline
    """
    nb_pipeline = None
    ##### Write code here #######

    nb_pipeline = Pipeline([
        ('vect', CountVectorizer()),
        ('tfidf', TfidfTransformer()),
        ('clf', MultinomialNB()),
    ])

    ##### End of your work ######
    return nb_pipeline


def build_logistic_regr():
    """

    Returns
    -------
        Pipeline
        An sklearn Pipeline
    """
    logistic_pipeline = None
    ##### Write code here #######

    logistic_pipeline = Pipeline([
        ('vect', CountVectorizer()),
        ('tfidf', TfidfTransformer()),
        ('clf', LogisticRegression(multi_class='ovr')),
    ])

    ##### End of your work ######
    return logistic_pipeline


def build_own_pipeline() -> Pipeline:
    """

    Returns
    -------
        Pipeline
        An sklearn Pipeline
    """
    pipeline = None
    ##### Write code here #######

    ##### End of your work ######
    return pipeline


def output_predictions(pipeline):
    """Load test data, predict using given pipeline, and write predictions to file.

    The output must be named "predictions.tsv" and must have the following format.
    Here, the first three examples were predicted to be 7,2,3, and the last were 
    predicted to be 6,6, and 2.

    Be sure not to permute the order of the examples in the test file.

        7
        2
        3
        .
        .
        .
        6
        6
        2

    """
    ##### Write code here #######
    pass
    ##### End of your work ######

# def testing(X_train, y_train_true, X_dev, y_dev_true):
#     from sklearn.feature_extraction.text import CountVectorizer
#     from sklearn.feature_extraction.text import TfidfTransformer
#     from sklearn.naive_bayes import MultinomialNB

#     # Count Vectorizer
#     train_vectorizer = CountVectorizer()
#     X_cv_train = train_vectorizer.fit_transform(X_train)
#     # print(vectorizer.get_feature_names())
#     # print(X.toarray())

#     # Tfid Transformer
#     tf_train_transformer = TfidfTransformer().fit(X_cv_train)
#     X_train_tfidf = tf_train_transformer.transform(X_cv_train)
#     # print(X_train_tf)

#     # Fit model
#     print("X_train_tfidf shape", X_train_tfidf.shape)

#     # print(tfidf_transformer.idf_)
#     # print(cv.get_feature_names())
#     clf = MultinomialNB().fit(X_train_tfidf, y_train_true)

#     # Predict validation set
#     # dev_vectorizer = CountVectorizer()
#     X_cv_dev = train_vectorizer.transform(X_dev)
#     print("fname", len(train_vectorizer.get_feature_names()))

#     # tf_dev_transformer = TfidfTransformer(use_idf=False).fit(X_cv_dev)
#     X_dev_tfidf = tf_train_transformer.transform(X_cv_dev)
#     print(tf_train_transformer.get_params())


#     predicted = clf.predict(X_dev_tfidf)

#     np_pred = np.array(predicted)
#     np_y = np.array(y_dev_true)
#     print("Predicted:")
#     print(np_pred)
#     print("True:")
#     print(np_y)

#     print("Correct:", np.sum(np_pred == np_y))
#     print("Wrong", np.sum(np_pred != np_y))

# def compare_result(pipe, name, X_dev, y_dev_true):
#     pred = pipe.predict(X_dev)
#     np_pred, np_y = np.array(pred), np.array(y_dev_true)
#     print("Pipe name = {}".format(name))
#     print("Correct:", np.sum(np_pred == np_y))
#     print("Wrong", np.sum(np_pred != np_y))

def main():
    X_train, y_train_true = load_data_file(TRAIN_FILE)
    X_dev, y_dev_true = load_data_file(DEV_FILE)
    X_test, _ = load_data_file(TEST_FILE, is_test_file=True)

    bayes_pipeline = build_naive_bayes()
    logistic_pipeline = build_logistic_regr()

    # testing(X_train, y_train_true, X_dev, y_dev_true)

    for name, pipeline in (
        ["Naive Bayes", bayes_pipeline,],
        ["Logistic Regression", logistic_pipeline,],
    ):
        if pipeline is not None:

            ##### Write code here #######

            model = pipeline.fit(X_train, y_train_true)
            dev_pred = model.predict(X_dev)
            labels = list(np.unique(np.array(y_train_true)))
            print("Pipe = {}".format(name))
            for averaging in ['micro', 'macro']:
                our_recall = our_metrics.recall(y_dev_true, dev_pred, labels=labels, average=averaging)
                our_precision = our_metrics.precision(y_dev_true, dev_pred, labels=labels, average=averaging)
                print("\tAveraging = {}\n\t\tRecall = {}\n\t\tPrecision = {}".format(averaging, our_recall, our_precision))

            test_pred = model.predict(X_test)
            np.savetxt("./test_output/test_output_{}.txt".format(name), np.array(test_pred), fmt='%d')

            ##### End of your work ######


if __name__ == "__main__":
    main()
